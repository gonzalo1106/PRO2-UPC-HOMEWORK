﻿namespace carpeta
{
	public class Program

	{
		public static void Main(string[] args)
		{

			// MatrizCadenas MC = new MatrizCadenas(8, 8);
			// MC.CargarMatrizDefault();

			// for (int i = 0; i < 4; i++)
			// {
			// 	//Serie X
			// 	int x = 0;
			// 	if (i < 1)
			// 	{
			// 		x = 0;
			// 	}
			// 	else
			// 	{
			// 		x = 7;
			// 	}

			// 	//Serie Y
			// 	int y = 0;
			// 	if (i == 0 || i == 1)
			// 	{
			// 		y = 0;
			// 	}
			// 	else
			// 	{
			// 		y = 0;
			// 	}
			// 	//Console.WriteLine(x +  " --- " + y);
			// 	MC.Insertar(x, y, "");
			// }

			// // MC.Insertar(4, 7, "Blanco");
			// // MC.Insertar(3, 0, "Blanco");
			// for (int i = 0; i < 8; i++)
			// {
			// 	MC.Insertar(i, 6, "Peon");
			// }
			// MC.Insertar(1, 1, "Blanco");
			// MC.Insertar(1, 1, "Blanco");
			// MC.Insertar(1, 2, "Blanco");
			// MC.Insertar(2, 1, "Blanco");
			// MC.Insertar(4, 1, "Peon");
			// MC.Insertar(5, 1, "Peon");
			// MC.Insertar(6, 1, "Peon");
			// MC.Insertar(7, 1, "Peon");
			// MC.Insertar(4, 0, "Rey");

			// MC.Insertar(3, 7, "Rey");


			// MC.Insertar(1, 0, "Blanco");
			// MC.Insertar(6, 0, "Caballo");
			// MC.Insertar(1, 7, "Caballo");
			// MC.Insertar(6, 7, "Caballo");


			// for (int i = 0; i < 4; i++)
			// {
			// 	//Serie X
			// 	int x = 0;
			// 	if (i < 2)
			// 	{
			// 		x = 1;
			// 	}
			// 	else
			// 	{
			// 		x = 6;
			// 	}

			// 	//Serie Y
			// 	int y = 0;
			// 	if (i == 0 || i == 3)
			// 	{
			// 		y = 0;
			// 	}
			// 	else
			// 	{
			// 		y = 7;
			// 	}
			// 	//Console.WriteLine(x +  " --- " + y);
			// 	MC.Insertar(x, y, "Caballo");
			// }
			// MC.Insertar(2, 0, "Alfil");
			// MC.Insertar(5, 0, "Alfil");
			// MC.Insertar(2, 7, "Alfil");
			// MC.Insertar(5, 7, "Alfil");

			// //MoverPeon
			// //string peonAux = MC.Obtener(2, 6);
			// //MC.Insertar(2, 6, MC.defaultValue);
			// //MC.Insertar(2, (6-1), peonAux);
			// MC.MoverBlackPeon(1, 6);
			// MC.MoverBlackPeon(3, 6);
			// MC.MoverBlackPeon(5, 6);
			// MC.MoverBlackPeon(5, 5);

			// //MC.MoverBlackAlfil(2, 7, 2, true);

			// MC.MostrarMatriz();

			TableroDamas tablero = new TableroDamas(8, 8);
            tablero.InicializarTablero();

            tablero.MostrarTablero();
		}
	}

	public class MatrizCadenas
	{
		public string[,] M; //Elemento de la Matriz
		public int fila;//Cantidad de filas
		public int columna;//Cantidad de columnas
		public string defaultValue = "▒▒▒▒▒▒▒";//Valor por defecto

		//El constructor dandole la cantidad X y Y
		public MatrizCadenas(int cantX, int cantY)
		{
			//Dimensionar la matriz
			M = new string[cantX, cantY];
			columna = cantX;
			fila = cantY;
		}

		//Cargar la matriz con valores por defecto
		public void CargarMatrizDefault()
		{
			//Dar valores por defecto a la matriz
			for (int x = 0; x < columna; x++)
			{
				for (int y = 0; y < fila; y++)
				{
					M[y, x] = defaultValue;
				}
			}
		}

		//Mostrar el contenido de la matriz
		public void MostrarMatriz()
		{
			string res = "";
			for (int x = 0; x < columna; x++)
			{
				for (int y = 0; y < fila; y++)
				{
					string dato = M[y, x];
					res = res + dato + ", ";
				}
				res = res + "\n";
			}
			Console.WriteLine(res);
		}

		public string Obtener(int posX, int posY)
		{
			return M[posX, posY];
		}
		public void Insertar(int posX, int posY, string ele)
		{
			int cant = CantCaracteres(ele);
			string espacios = "";
			if (cant <= 7)
			{
				int difCaracteres = 7 - cant;
				for (int i = 0; i < difCaracteres; i++)
				{
					espacios = espacios + " ";
				}
			}
			M[posX, posY] = ele + espacios;
		}

		public int CantCaracteres(string dato)
		{
			return dato.Length;
		}



		public void LlenarMatriz_v1()
		{
			int i = 1;
			string dato = "UPC";
			for (int x = 0; x < columna; x++)
			{
				for (int y = 0; y < fila; y++)
				{
					M[x, y] = dato;
				}
				dato = dato + "_" + i;
				i++;
			}
		}

		public void MoverBlackPeon(int x, int y)
		{
			string peonAux = Obtener(x, y);
			Insertar(x, y, defaultValue);
			y = y - 1;
			Insertar(x, y, peonAux);
		}

		public void MoverWhitePeon(int x, int y)
		{
			string peonAux = Obtener(x, y);
			Insertar(x, y, defaultValue);
			y = y + 1;
			Insertar(x, y, peonAux);
		}




	}


	 public class TableroDamas
    {
        public string[,] Tablero; 
        public int Filas;
        public int Columnas;
        public string CasillaVacia ="▒▒▒▒▒▒▒,";
        public string FichaBlanca = "Blanca,";
        public string FichaRoja = "Roja,";

        public TableroDamas(int filas, int columnas)
        {
            Tablero = new string[filas, columnas];
            Filas = filas;
            Columnas = columnas;
        }

        public void InicializarTablero()
        {
            for (int x = 0; x < Filas; x++)
            {
                for (int y = 0; y < Columnas; y++)
                {
                    if ((x + y) % 2 == 0)
                    {
                        if (x < 3)
                        {
                            Tablero[x, y] = FichaBlanca;
                        }
                        else if (x >= 5)
                        {
                            Tablero[x, y] = FichaRoja;
                        }
                        else
                        {
                            Tablero[x, y] = CasillaVacia;
                        }
                    }
                    else
                    {
                        Tablero[x, y] = CasillaVacia;
                    }
                }
            }
        }

        public void MostrarTablero()
        {
            for (int x = 0; x < Filas; x++)
            {
                for (int y = 0; y < Columnas; y++)
                {
                    Console.Write(Tablero[x, y]);
                }
                Console.WriteLine();
            }
        }
    }
}
                

                

                
            
        
    

